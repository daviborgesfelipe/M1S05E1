export function digaOla() {
    console.log(`Olá!`);
}