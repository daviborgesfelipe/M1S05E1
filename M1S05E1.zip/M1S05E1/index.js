import {digaOla} from "./saudacao.js"
digaOla()